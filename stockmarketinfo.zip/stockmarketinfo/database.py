import sqlite3
import os

DB_NAME = "quotes.db"

def init_db():
    if os.path.exists(DB_NAME):
        os.remove(DB_NAME)

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE quotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT,
            price REAL,
            change REAL,
            percent REAL,
            timestamp TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_quote(q):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        INSERT INTO quotes (ticker, price, change, percent, timestamp)
        VALUES (?, ?, ?, ?, ?)
    """, (q["ticker"], q["price"], q["change"], q["percent"], q["timestamp"]))
    conn.commit()
    conn.close()

def get_recent_quotes(limit=10):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        SELECT ticker, price, change, percent, timestamp
        FROM quotes
        ORDER BY id DESC
        LIMIT ?
    """, (limit,))
    rows = c.fetchall()
    conn.close()
    return rows
