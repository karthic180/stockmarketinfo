INDEX_TICKERS = {
    "DOW JONES": "^DJI",
    "NASDAQ": "^IXIC",
    "S&P 500": "^GSPC",
    "FTSE 100": "^FTSE",
    "DAX": "^GDAXI",
    "CAC 40": "^FCHI",
    "NIKKEI 225": "^N225",
    "HANG SENG": "^HSI",
    "ASX 200": "^AXJO",
    "TSX": "^GSPTSE",
    "NIFTY 50": "^NSEI",
    "SENSEX": "^BSESN",
    "SHANGHAI": "000001.SS"
}


def fuzzy_match(query: str, symbols):
    """Very simple substring-based fuzzy match."""
    query = query.upper()
    best = None
    for s in symbols:
        if query in s:
            best = s
    return best
