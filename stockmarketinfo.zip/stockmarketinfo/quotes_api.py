import yfinance as yf
import json
import os
import time
import socket

CACHE_FILE = "cache.json"


# -------------------------
# Cache helpers
# -------------------------
def load_cache():
    if not os.path.exists(CACHE_FILE):
        return {"last_update": "", "indices": {}, "quotes": {}}
    try:
        with open(CACHE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {"last_update": "", "indices": {}, "quotes": {}}


def save_cache(cache):
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f, indent=2)


# -------------------------
# Connectivity checks
# -------------------------
def internet_available():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=1)
        return True
    except OSError:
        return False


def yahoo_available():
    try:
        socket.create_connection(("query1.finance.yahoo.com", 443), timeout=1)
        return True
    except OSError:
        return False


# -------------------------
# Data status (for UI)
# -------------------------
def get_data_status():
    cache = load_cache()
    last_update = cache.get("last_update", "N/A")
    online = internet_available() and yahoo_available()

    if online:
        status = "LIVE"
        notice = "Market data may be delayed by up to 15 minutes."
    else:
        if cache.get("indices") or cache.get("quotes"):
            status = "CACHED"
            notice = "Using last saved data (offline mode). Prices may be outdated."
        else:
            status = "UNAVAILABLE"
            notice = "No live data and no cached data available."

    return status, last_update, notice


# -------------------------
# Live API calls
# -------------------------
def get_indices():
    try:
        tickers = [
            "^DJI", "^IXIC", "^GSPC", "^FTSE", "^GDAXI", "^FCHI",
            "^N225", "^HSI", "^AXJO", "^GSPTSE", "^NSEI", "^BSESN",
            "000001.SS"
        ]
        data = yf.download(tickers, period="1d", interval="1d", progress=False)

        results = []
        for t in tickers:
            price = data["Close"][t].iloc[-1]
            prev = data["Open"][t].iloc[-1]
            change = price - prev
            percent = (change / prev) * 100
            results.append({
                "name": t,
                "ticker": t,
                "price": float(price),
                "change": float(change),
                "percent": float(percent),
                "timestamp": time.ctime()
            })
        return results
    except Exception:
        return None


def get_quote(ticker: str):
    try:
        q = yf.Ticker(ticker).info
        price = q.get("regularMarketPrice")
        change = q.get("regularMarketChange")
        percent = q.get("regularMarketChangePercent")
        if price is None:
            return None
        return {
            "ticker": ticker.upper(),
            "price": float(price),
            "change": float(change) if change is not None else 0.0,
            "percent": float(percent) if percent is not None else 0.0,
            "timestamp": time.ctime()
        }
    except Exception:
        return None


# -------------------------
# Cached wrappers
# -------------------------
def get_indices_cached():
    cache = load_cache()

    if internet_available() and yahoo_available():
        live = get_indices()
        if live:
            cache["indices"] = {item["ticker"]: item for item in live}
            cache["last_update"] = time.ctime()
            save_cache(cache)
            return live

    if cache["indices"]:
        return list(cache["indices"].values())

    return None


def get_quote_cached(ticker: str):
    cache = load_cache()

    if internet_available() and yahoo_available():
        live = get_quote(ticker)
        if live:
            cache["quotes"][ticker.upper()] = live
            cache["last_update"] = time.ctime()
            save_cache(cache)
            return live

    return cache["quotes"].get(ticker.upper())


# -------------------------
# Auto-cache warm
# -------------------------
def warm_cache():
    if not (internet_available() and yahoo_available()):
        return

    data = get_indices()
    if data:
        cache = load_cache()
        cache["indices"] = {item["ticker"]: item for item in data}
        cache["last_update"] = time.ctime()
        save_cache(cache)
