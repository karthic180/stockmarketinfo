# Stock Market Information  
A lightweight, multi‑interface market data application featuring both a **web dashboard** and a **terminal interface**.  
Designed to be clean, reliable, and easy to use — ideal for learning, experimentation, and portfolio demonstration.

This project showcases:
- API integration  
- Offline‑first design  
- Caching and fallback logic  
- Web UI development with Streamlit  
- CLI application design  
- Configuration‑driven architecture  
- Clean, maintainable Python code  

All code is original and copyright‑free.

---

## Features

### 🌐 Web Dashboard
- Clean, tab‑based navigation  
- Welcome page with instructions  
- Market overview (local & global indices)  
- Symbol lookup with fuzzy matching  
- Watchlist management  
- Exit tab that signals the launcher to close  
- Automatic fallback to cached data when offline  
- Data sourced from Yahoo Finance (via `yfinance`)  

### 💻 Terminal Interface
- Simple, readable layout  
- Local and global market views  
- Symbol lookup with LIVE/CACHED status  
- Watchlist with price and percentage change  
- Clear data status line:
  - **LIVE** when online  
  - **CACHED** when offline  
  - Timestamp of last successful update  
  - Market delay notice  

---

## Data Reliability & Source Information

This application retrieves market data from **Yahoo Finance** using the `yfinance` library.

Because of how financial data providers operate:

- **Prices may be delayed by up to 15 minutes**  
- **Live data is used whenever available**  
- **Cached data is used automatically when live data cannot be retrieved**  
- **The interface clearly indicates whether data is LIVE or CACHED**  
- **Timestamps show when the last successful update occurred**

This ensures the application remains usable even without an internet connection.

---

## System Checks & Fallback Logic

Before launching the web interface, the application performs several checks:

- Python environment validation  
- Streamlit availability  
- Port availability (8501)  
- Internet connectivity  
- DNS resolution  
- Yahoo Finance reachability  
- Cache freshness  

If any critical check fails, the launcher automatically falls back to the **terminal interface**, ensuring the application always remains functional.

---

## Project Structure

```text
market-terminal/
│
├── run.py               # Launcher: diagnostics, menu, cache warm
├── web_app.py           # Streamlit web UI
├── terminal_app.py      # CLI interface
├── quotes_api.py        # Data access + caching + connectivity checks
├── fuzzy.py             # Fuzzy matching + index ticker mapping
├── settings.json        # Configuration for markets, UI, diagnostics, cache
├── cache.json           # Auto-created cache file (ignored in git)
├── requirements.txt     # Python dependencies
├── README.md            # Project documentation
└── LICENSE              # MIT license
