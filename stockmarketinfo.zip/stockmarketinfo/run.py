import subprocess
import sys
import time
import webbrowser
import signal
import os
import socket
import json

from quotes_api import warm_cache


with open("settings.json", "r") as f:
    settings = json.load(f)

diag = settings["diagnostics"]


def clear():
    print("\033c", end="")


def startup_animation():
    if not diag.get("show_startup_animation", True):
        return
    clear()
    text = "Starting Stock Market Information"
    for i in range(3):
        print(text + "." * i)
        time.sleep(0.25)
        clear()
    print(text + "...\n")
    time.sleep(0.3)


def check_streamlit():
    try:
        subprocess.run(
            [sys.executable, "-m", "streamlit", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        return True
    except Exception:
        return False


def check_port(port=8501):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(("127.0.0.1", port))
    sock.close()
    return result == 0


def check_internet():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=1)
        return True
    except OSError:
        return False


def check_dns():
    try:
        socket.gethostbyname("query1.finance.yahoo.com")
        return True
    except OSError:
        return False


def check_yahoo():
    try:
        socket.create_connection(("query1.finance.yahoo.com", 443), timeout=1)
        return True
    except OSError:
        return False


def run_diagnostics():
    if not diag.get("show_environment_checks", True):
        return True

    print("Running environment checks...\n")
    time.sleep(0.2)

    print("✔ Python environment detected")

    if not check_streamlit():
        print("✖ Streamlit not available — web interface will be disabled")
        return False
    print("✔ Streamlit available")

    if check_port(8501):
        print("✖ Port 8501 already in use — web interface will be disabled")
        return False
    print("✔ Port 8501 available")

    if diag.get("check_internet", True):
        if check_internet():
            print("✔ Internet connection detected")
        else:
            print("✖ Internet unavailable — live data may not be accessible")
            return False

    if diag.get("check_dns", True):
        if check_dns():
            print("✔ DNS resolution OK")
        else:
            print("✖ DNS resolution failed — live data may not be accessible")
            return False

    if diag.get("check_yahoo", True):
        if check_yahoo():
            print("✔ Yahoo Finance reachable")
        else:
            print("✖ Yahoo Finance unreachable — live data may not be accessible")
            return False

    print("\nEnvironment checks passed — web interface available.\n")
    return True


def launch_web():
    devnull = open(os.devnull, "w")

    proc = subprocess.Popen(
        [sys.executable, "-m", "streamlit", "run", "web_app.py"],
        stdout=devnull,
        stderr=devnull,
        preexec_fn=None if sys.platform == "win32" else lambda: signal.signal(signal.SIGINT, signal.SIG_IGN),
    )

    webbrowser.open("http://localhost:8501", new=1)
    print("Web interface running at: http://localhost:8501\n")

    while True:
        if os.path.exists("exit.flag"):
            os.remove("exit.flag")
            proc.terminate()
            return True

        if proc.poll() is not None:
            return False

        time.sleep(0.2)


def run_terminal():
    clear()
    print("Launching terminal mode...\n")
    import terminal_app
    terminal_app.main()


def show_menu():
    print("==============================================")
    print("           STOCK MARKET INFORMATION           ")
    print("==============================================")
    print("1) Launch Web Interface")
    print("2) Launch Terminal Mode")
    print("3) Exit")
    print("==============================================")
    return input("Select an option: ").strip()


if __name__ == "__main__":
    startup_animation()
    warm_cache()
    diagnostics_ok = run_diagnostics()
    print()

    while True:
        choice = show_menu()

        if choice == "1":
            if diagnostics_ok:
                web_ok = launch_web()
                if not web_ok:
                    run_terminal()
            else:
                run_terminal()

        elif choice == "2":
            run_terminal()

        elif choice == "3":
            clear()
            print("Goodbye.")
            time.sleep(0.5)
            sys.exit(0)

        else:
            print("Invalid selection.")
            time.sleep(1)
            clear()
