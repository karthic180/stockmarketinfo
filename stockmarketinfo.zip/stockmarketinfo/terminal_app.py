import time
import json

from quotes_api import (
    get_indices_cached,
    get_quote_cached,
    load_cache,
    internet_available,
    yahoo_available,
    get_data_status,
)
from fuzzy import fuzzy_match, INDEX_TICKERS


with open("settings.json", "r") as f:
    settings = json.load(f)

market_settings = settings["market_settings"]
ui_terminal = settings["ui_settings"]["terminal"]


def clear():
    if ui_terminal.get("clear_screen_on_navigation", True):
        print("\033c", end="")


def pause():
    input("\nPress Enter to continue...")


def show_header():
    if not ui_terminal.get("show_header", True):
        return
    print("==================================================")
    print("              STOCK MARKET INFORMATION            ")
    print("                    TERMINAL VIEW                 ")
    print("==================================================\n")


def data_status_header():
    status, last_update, notice = get_data_status()
    print(f"DATA SOURCE: {status}")
    print(f"LAST UPDATE: {last_update}")
    print(f"NOTICE: {notice}\n")
    return status


def main_menu():
    clear()
    show_header()
    print("MAIN MENU")
    print("--------------------------------------------------")
    print("1) Local Markets")
    print("2) Global Markets")
    print("3) Symbol Lookup")
    print("4) Watchlist")
    print("5) Exit")
    print("--------------------------------------------------")
    return input("Select an option: ").strip()


def market_overview(mode="local"):
    clear()
    show_header()
    print(f"{mode.upper()} MARKETS")
    print("--------------------------------------------------\n")

    wanted = (
        market_settings["local_markets"]
        if mode == "local"
        else market_settings["global_markets"]
    )

    indices = get_indices_cached()
    data_status_header()

    if not indices:
        print("No market data available (offline and no cache).")
        pause()
        return

    filtered = [q for q in indices if q["ticker"] in wanted]

    if not filtered:
        print("No index data available for the selected set.")
        pause()
        return

    print(f"{'TICKER':10} {'PRICE':>12} {'CHANGE':>10} {'PCT':>8}")
    print("--------------------------------------------------")
    for q in filtered:
        print(f"{q['ticker']:10} {q['price']:12.2f} {q['change']:10.2f} {q['percent']:8.2f}%")

    pause()


def symbol_lookup():
    clear()
    show_header()
    print("SYMBOL LOOKUP")
    print("--------------------------------------------------\n")

    ticker = input("Enter a symbol (e.g., AAPL, MSFT, ^DJI): ").strip()

    if not ticker:
        return

    suggestion = fuzzy_match(ticker, list(INDEX_TICKERS.values()))
    if suggestion and suggestion != ticker.upper():
        print(f"\nDid you mean: {suggestion}?")
        use = input("Use suggestion? (y/n): ").lower()
        if use == "y":
            ticker = suggestion

    print("\nFetching data...\n")

    q = get_quote_cached(ticker)
    status = data_status_header()

    if not q:
        print("No data available for this symbol.")
        pause()
        return

    print(f"SYMBOL:   {q['ticker']}")
    print(f"PRICE:    {q['price']:.2f}")
    print(f"CHANGE:   {q['change']:+.2f}")
    print(f"PERCENT:  {q['percent']:+.2f}%")
    print(f"TIME:     {q['timestamp']}")
    print(f"SOURCE:   Yahoo Finance ({status})")

    pause()


def watchlist_menu():
    clear()
    show_header()
    print("WATCHLIST")
    print("--------------------------------------------------\n")

    if "watchlist" not in globals():
        globals()["watchlist"] = []

    data_status_header()

    print("Current Watchlist:")
    if not watchlist:
        print("  (empty)")
    else:
        print(f"{'TICKER':10} {'PRICE':>12} {'CHANGE':>10} {'PCT':>8}")
        print("--------------------------------------------------")
        for t in watchlist:
            q = get_quote_cached(t)
            if q:
                print(f"{t:10} {q['price']:12.2f} {q['change']:10.2f} {q['percent']:8.2f}%")
            else:
                print(f"{t:10} {'N/A':>12} {'N/A':>10} {'N/A':>8}")

    print("\nOptions:")
    print("1) Add symbol")
    print("2) Remove symbol")
    print("3) Back")
    choice = input("> ").strip()

    if choice == "1":
        sym = input("Enter symbol to add: ").upper().strip()
        if sym:
            watchlist.append(sym)
    elif choice == "2":
        sym = input("Enter symbol to remove: ").upper().strip()
        if sym in watchlist:
            watchlist.remove(sym)

    pause()


def main():
    while True:
        choice = main_menu()

        if choice == "1":
            market_overview(mode="local")
        elif choice == "2":
            market_overview(mode="global")
        elif choice == "3":
            symbol_lookup()
        elif choice == "4":
            watchlist_menu()
        elif choice == "5" or choice.lower() == "exit":
            clear()
            print("Closing terminal. Goodbye.")
            time.sleep(0.5)
            return
        else:
            print("Invalid choice.")
            time.sleep(0.5)
