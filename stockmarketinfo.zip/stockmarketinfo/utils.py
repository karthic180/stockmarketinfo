import sys

USE_COLOUR = sys.stdout.isatty()

GREEN = "\033[92m" if USE_COLOUR else ""
RED = "\033[91m" if USE_COLOUR else ""
RESET = "\033[0m" if USE_COLOUR else ""

def colour_number(value):
    if value is None:
        return "N/A"
    if value > 0:
        return f"{GREEN}{value:+.2f}{RESET}"
    if value < 0:
        return f"{RED}{value:+.2f}{RESET}"
    return f"{value:+.2f}"

def colour_percent(value):
    if value is None:
        return "N/A"
    if value > 0:
        return f"{GREEN}{value:+.2f}%{RESET}"
    if value < 0:
        return f"{RED}{value:+.2f}%{RESET}"
    return f"{value:+.2f}%"
import socket

def check_internet(host="8.8.8.8", port=53, timeout=2):
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
        return True
    except:
        return False
