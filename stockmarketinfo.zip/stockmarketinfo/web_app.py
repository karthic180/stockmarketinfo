import streamlit as st
import time
import json
import os

from quotes_api import (
    get_indices_cached,
    get_quote_cached,
    get_data_status,
)
from fuzzy import fuzzy_match, INDEX_TICKERS


# ---------------------------------------------------------
# Load settings
# ---------------------------------------------------------
with open("settings.json", "r") as f:
    settings = json.load(f)

market_settings = settings["market_settings"]
ui_web = settings["ui_settings"]["web"]


# ---------------------------------------------------------
# Streamlit page config
# ---------------------------------------------------------
st.set_page_config(
    page_title="Stock Market Information",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# ---------------------------------------------------------
# Helpers
# ---------------------------------------------------------
def loading_dots(duration=1.0):
    """Simple loading animation."""
    placeholder = st.empty()
    dots = ["", ".", "..", "..."]
    start = time.time()
    while time.time() - start < duration:
        for d in dots:
            placeholder.write(f"Loading{d}")
            time.sleep(0.15)
    placeholder.empty()


def static_index_bar(indices_data):
    """Display a compact index bar."""
    parts = []
    for q in indices_data:
        price = f"{q['price']:.2f}"
        percent = f"{q['percent']:+.2f}%"
        parts.append(f"{q['ticker']} {price} ({percent})")
    line = "   |   ".join(parts)
    st.markdown(f"### {line}")


def status_bar():
    """Show data source, last update, and notice."""
    status, last_update, notice = get_data_status()
    st.markdown(
        f"""
<div style="background-color:#f0f0f0;padding:10px;border-radius:6px;margin-bottom:10px;">
  <strong>Data Source:</strong> {status}<br>
  <strong>Last Update:</strong> {last_update}<br>
  <span style="color:#555;">{notice}</span>
</div>
""",
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------
# Tabs
# ---------------------------------------------------------
tabs = st.tabs(["Welcome", "Markets", "Watchlist", "Exit"])


# ---------------------------------------------------------
# WELCOME TAB
# ---------------------------------------------------------
with tabs[0]:
    st.title("Stock Market Information")
    st.subheader("Welcome")

    if ui_web.get("show_welcome_message", True):
        st.write(
            """
This dashboard provides a simple, professional way to monitor global stock market data.

**How to use this tool:**
- **Markets Tab** – View local or global indices and look up individual symbols.
- **Watchlist Tab** – Add symbols you want to track and view their latest prices.
- **Exit Tab** – Close the application safely.

Data is sourced from Yahoo Finance. Prices may be delayed by up to 15 minutes.
If live data is unavailable, cached data will be used automatically.
"""
        )

    status_bar()


# ---------------------------------------------------------
# MARKETS TAB
# ---------------------------------------------------------
with tabs[1]:
    status_bar()
    sub = st.tabs(["Overview", "Lookup"])

    # -------------------------
    # MARKET OVERVIEW
    # -------------------------
    with sub[0]:
        st.subheader("Market Overview")

        if "market_mode" not in st.session_state:
            st.session_state.market_mode = market_settings["default_mode"]

        if ui_web.get("enable_global_toggle_button", True):
            if st.button(
                "Switch to Global Markets"
                if st.session_state.market_mode == "local"
                else "Switch to Local Markets"
            ):
                st.session_state.market_mode = (
                    "global" if st.session_state.market_mode == "local" else "local"
                )

        loading_dots()

        all_indices = get_indices_cached()

        if not all_indices:
            st.warning("No market data available (offline and no cache).")
        else:
            if ui_web.get("show_cached_notice", True):
                st.caption("Live or cached data is shown depending on availability.")

            if st.session_state.market_mode == "local":
                wanted = market_settings["local_markets"]
            else:
                wanted = market_settings["global_markets"]

            filtered = [q for q in all_indices if q["ticker"] in wanted]

            if filtered:
                if ui_web.get("show_index_bar", True):
                    static_index_bar(filtered)
                else:
                    st.write(filtered)
            else:
                st.write("No index data available for the selected set.")

    # -------------------------
    # SYMBOL LOOKUP
    # -------------------------
    with sub[1]:
        st.subheader("Symbol Lookup")

        ticker = st.text_input("Enter a market symbol (e.g., AAPL, MSFT, ^DJI):")

        if ticker:
            known_symbols = list(INDEX_TICKERS.values())
            suggestion = fuzzy_match(ticker, known_symbols)

            if suggestion and suggestion != ticker.upper():
                st.info(f"Possible match: **{suggestion}**")
                if st.button("Use Suggested Symbol"):
                    ticker = suggestion

        if st.button("Search"):
            loading_dots()
            q = get_quote_cached(ticker)

            status_bar()

            if q:
                st.success("Data retrieved successfully.")
                st.write(f"**Symbol:** {q['ticker']}")
                st.write(f"**Price:** {q['price']:.2f}")
                st.write(f"**Change:** {q['change']:+.2f}")
                st.write(f"**Percent:** {q['percent']:+.2f}%")
                st.write(f"**Timestamp:** {q['timestamp']}")
            else:
                st.error("No data available for this symbol.")


# ---------------------------------------------------------
# WATCHLIST TAB
# ---------------------------------------------------------
with tabs[2]:
    status_bar()
    st.subheader("Watchlist")

    if "watchlist" not in st.session_state:
        st.session_state.watchlist = []

    new_ticker = st.text_input("Add a symbol to your watchlist:")

    if st.button("Add to Watchlist"):
        if new_ticker:
            st.session_state.watchlist.append(new_ticker.upper())
            st.success(f"{new_ticker.upper()} added to watchlist.")

    if st.session_state.watchlist:
        st.write("### Current Watchlist")
        for t in st.session_state.watchlist:
            q = get_quote_cached(t)
            if q:
                st.write(f"{t}: {q['price']:.2f} ({q['percent']:+.2f}%)")
            else:
                st.write(f"{t}: No data available")


# ---------------------------------------------------------
# EXIT TAB
# ---------------------------------------------------------
with tabs[3]:
    status_bar()
    st.subheader("Exit Application")

    st.write("Click below to close the dashboard.")

    if st.button("Exit Now", type="primary"):
        with open("exit.flag", "w") as f:
            f.write("exit")
        st.success("The application is closing. You may now close this browser tab.")
        st.stop()
